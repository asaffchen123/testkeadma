import React, { Component } from 'react'
import Board from "./component/board"
import Card from './component/card'
import {connect} from "react-redux"
import "./app.css"
 class App extends Component {
  numberOf=new Array(9).fill("")
  sizeFix=(arr)=>{
    const widtharray=[]
    console.log(arr)
    arr.map(ar=>{
        console.log(ar.length)
        
        widtharray.push(ar.length)
    })
    return widtharray
}
  render() {
    const {arr}=this.props
    console.log(arr[arr.length-1])
    console.log(`${50*(arr[arr.length-1].length)}`)
    return (
      <>
        
      <div className="all">
        <div className="flx">
        {this.props.arrPar.map((arr,index)=>{
                  return (<p style={{marginLeft:`${17*this.sizeFix(this.props.arr)[index]}px`}}>{arr}</p>)
                })}
        </div>
      
      {this.numberOf.map((v,index)=>{
        return(
  
        <Board className="board" id="board2">
              
                <ul className="cards">
                
                
                  {this.props.arr.map((l,index)=>{
                    return(
                        <Card  style={{width:`${25*this.sizeFix(this.props.arr)[index]}px`}} id={`card${index+1}`} className="card cards"  draggable="true">
                          {l}
                        </Card>
                    )     
                  })}
                  </ul>
            </Board>)
      })}
      </div>
    </>
    )
  }
}

const mapStateToProps=state=>{
  return{
      zeut:state.zeut,
      name:state.name,
      hourHarig:state.hourHarig,
      hourYadani:state.hourYadani,
      hours:state.hours,
      total:state.total,
      arr:state.arr,
      arrPar:state.arrPar
  }
}
const mapDispatchToProps=dispatch=>{
  return{

  }
}

export default connect(mapStateToProps,mapDispatchToProps)(App)
