import React, { Component } from 'react'
import {connect} from "react-redux"
class Card extends Component {
    dragStart=  e=>{
        const target=e.target
        
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", target.id);
        // target.style.display="none"

    }
    dragOver=e=>{
        e.stopPropagation()
        
    }

  
    render() {
        const {arr} =this.props
        
        
        return (
            <div 
            id={this.props.id}
            className={`${this.props.className} each`}
            draggable="true"
            onDragEnd={this.dragOver}
            onDragStart={this.dragStart}
            style={this.props.style}
            >
                {this.props.children}
            </div>
        )
    }
}


const mapStateToProps=state=>{
    return{
        
        name:state.name,
        hourHarig:state.hourHarig,
        hourYadani:state.hourYadani,
        hours:state.hours,
        total:state.total,
        arr:state.arr
    }
}

const mapDispatchToProps=dispatch=>{
    return{

    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Card)
