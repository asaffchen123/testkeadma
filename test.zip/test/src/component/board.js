import React, { Component } from 'react'
import {connect} from "react-redux"
class Board extends Component {
    
    drop= e=>{
        e.preventDefault()
        const card_id= e.dataTransfer.getData("text/plain")
        console.log(e.dataTransfer)
        e.target.appendChild(document.getElementById(card_id))
        
        
    }
  
    allowDrop=(e)=>{
        e.preventDefault()
    }
    render() {
        
        return (
            <>
          
            <div 
            id={this.props.id}
            className={this.props.className}
            onDrop={this.drop}
            onDragOver={this.allowDrop}
            >
                {this.props.children}
            </div>
            </>
        )
    }
}


const mapStateToProps=state=>{
    return{
        zeut:state.zeut,
        name:state.name,
        hourHarig:state.hourHarig,
        hourYadani:state.hourYadani,
        hours:state.hours,
        total:state.total,
        classname:state.classame,
        arrPar:state.arrPar
    }
}

const mapDispatchToProps=dispatch=>{
    return{

    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Board)