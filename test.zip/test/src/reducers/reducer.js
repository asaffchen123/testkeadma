const initialState={

    zeut:203483924,
    name:"יואב שרון",
    hourHarig:"4:00",
    hourYadani:"4:00",
    hours:"155.00",
    total:"159.00",
   
    arr:["159.00",
    "155.00",
        "4:00",
        "4:00",
        "יואב שרון",
        "203483924",],
    arrPar:[
        "שעות כולל",
        "שעות",
        "שעות חריג",
        "שעות ידני",
        "שם",
        "תעודת זהות"
    ]
   
   
   
}

 const reducer=(state=initialState,action)=>{
    switch(action.type){
        default:return{
            ...state
        }
    }
}


export default reducer